#!/bin/sh
set -eu
source_dir=$(CDPATH='' cd -- "$(dirname -- "$0")" && pwd)
app_dir=${XDG_DATA_HOME:-"$HOME/.local/share"}/zryspoty
desktop_dir=${XDG_DATA_HOME:-"$HOME/.local/share"}/applications
mkdir -p "$app_dir/assets" "$desktop_dir"
cp "$source_dir"/index.html "$source_dir"/app.js "$source_dir"/style.css "$source_dir"/manifest.webmanifest "$source_dir"/sw.js "$source_dir"/icon*.png "$source_dir"/ZRYSPOTY "$app_dir/"
cp "$source_dir"/assets/* "$app_dir/assets/"
chmod +x "$app_dir/ZRYSPOTY"
# Desktop Entry wymaga osobnego cytowania znaków specjalnych w polu Exec.
exec_path=$(printf '%s' "$app_dir/ZRYSPOTY" | sed 's/[%]/%%/g;s/[\\"$`]/\\&/g')
exec_path=$(printf '%s' "$exec_path" | sed 's/\\/\\\\/g')
icon_path=$(printf '%s' "$app_dir/icon.png" | sed 's/\\/\\\\/g')
cat > "$desktop_dir/pl.zryspoty.player.desktop" <<APP
[Desktop Entry]
Type=Application
Name=ZRYSPOTY
Comment=Lokalny odtwarzacz muzyki
Exec="$exec_path"
Icon=$icon_path
Categories=AudioVideo;Audio;Player;
Terminal=false
APP
printf '%s\n' 'ZRYSPOTY jest dostępne w menu aplikacji.'

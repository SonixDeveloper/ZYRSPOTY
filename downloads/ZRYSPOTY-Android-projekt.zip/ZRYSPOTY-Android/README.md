# ZRYSPOTY na Androida

Wymagania do zbudowania projektu to JDK 17, Gradle 8.11.1 oraz Android SDK Platform 35. W Android Studio otwórz folder projektu i wybierz opcję budowania APK. Możesz też wykonać `gradle assembleDebug` z tego folderu. Podpisany testowo plik do instalacji pojawi się w `build/outputs/apk/debug/`.

Aplikacja zawiera lokalny odtwarzacz, utwory demonstracyjne i import plików przez systemowy selektor Androida. Link „Wyszukaj w Spotify” otwiera Spotify poza aplikacją.
